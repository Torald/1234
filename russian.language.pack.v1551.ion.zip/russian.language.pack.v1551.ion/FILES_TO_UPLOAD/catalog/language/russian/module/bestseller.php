<?php
// Heading 
$_['heading_title'] = 'Лидеры продаж';

// Text
$_['text_reviews']	= 'Отзывов: %s';
?>