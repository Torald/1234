<?php
// Heading 
$_['heading_title']    = 'Личный кабинет';

// Text
$_['text_register']    = 'Регистрация';
$_['text_login']       = 'Вход';
$_['text_logout']      = 'Выход';
$_['text_forgotten']   = 'Забыли пароль?';
$_['text_account']     = 'Личный кабинет';
$_['text_edit']        = 'Изменить учетную запись';
$_['text_password']    = 'Изменить пароль';
$_['text_address']     = 'Мои адреса';;
$_['text_wishlist']    = 'Мои заметки';
$_['text_order']       = 'История заказов';
$_['text_download']    = 'Файлы для скачивания';
$_['text_return']      = 'Возвраты';
$_['text_transaction'] = 'История платежей';
$_['text_newsletter']  = 'Редактировать подписку';
?>