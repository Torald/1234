<?php
// Heading 
$_['heading_title']	= 'Акции';

// Text
$_['text_reviews']	= 'Отзывов: %s';
?>