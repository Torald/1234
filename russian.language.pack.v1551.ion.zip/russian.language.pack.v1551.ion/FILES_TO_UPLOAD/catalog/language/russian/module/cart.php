<?php
// Heading 
$_['heading_title'] = 'Корзина покупок';

// Text
$_['text_items']    = '%s товар(ов) - %s';
$_['text_empty']    = 'Корзина покупок пуста!';
$_['text_cart']     = 'Просмотр корзины';
$_['text_checkout'] = 'Оформить заказ';
?>