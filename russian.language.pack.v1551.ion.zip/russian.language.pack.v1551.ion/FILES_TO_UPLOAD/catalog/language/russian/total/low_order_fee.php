<?php
$_['text_low_order_fee'] = 'Минимальная сумма заказа';
?>