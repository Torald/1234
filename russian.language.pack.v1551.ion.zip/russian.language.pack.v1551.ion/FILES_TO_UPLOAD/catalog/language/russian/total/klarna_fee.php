<?php
$_['text_klarna_fee'] = 'Дополнительная плата';
?>