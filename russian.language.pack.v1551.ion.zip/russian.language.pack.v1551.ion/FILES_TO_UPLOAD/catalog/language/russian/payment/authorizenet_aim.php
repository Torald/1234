<?php
// Text
$_['text_title'] 		   = 'Кредитная карта / Дебетовая карта (Authorize.Net)';
$_['text_credit_card']     = 'Кредитная карта Детали';
$_['text_wait']            = 'Пожалуйста подождите!';

// Entry
$_['entry_cc_owner']       = 'Карта:';
$_['entry_cc_number']      = 'Номер катры:';
$_['entry_cc_expire_date'] = 'Дата окончания срока действия карты:';
$_['entry_cc_cvv2']        = 'Секретный Код карты (CVV2):';
?>