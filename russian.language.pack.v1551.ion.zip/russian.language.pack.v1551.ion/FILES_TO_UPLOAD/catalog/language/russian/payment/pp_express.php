<?php
// Text
$_['text_title'] = 'PayPal Express (including Credit Cards and Debit Cards)';
?>