<?php
// Text
$_['text_home']           = 'Главная';
$_['text_wishlist']       = 'Заметки (%s)';
$_['text_shopping_cart']  = 'Корзина покупок';
$_['text_search']         = 'Поиск';
$_['text_welcome']        = '<a href="%s">Войти</a> | <a href="%s">Регистрация</a>';
$_['text_logged']         = 'Добро пожаловать <a href="%s">%s</a> <b>(</b> <a href="%s">Выйти</a> <b>)</b>';
$_['text_account']        = 'Личный кабинет';
$_['text_checkout']       = 'Оформить заказ';
?>