<?php
// Heading
$_['heading_title']    = 'Google Base';

// Text   
$_['text_feed']        = 'Каналы продвижения';
$_['text_success']     = 'Настройки модуля обновлены!';

// Entry
$_['entry_status']     = 'Статус:';
$_['entry_data_feed']  = 'URL канала:';

// Error
$_['error_permission'] = 'У Вас нет прав для управления этим модулем!';
?>