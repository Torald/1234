Russian:
-----------------------------------------------------------------------------
Версия Opencart v1.5.5.1, v1.5.5.x

Залить папки(admin, catalog) из FILES_TO_UPLOAD в корневую папку OpenCart

Перейдите в System->Localisation->Languages и добавьте Русский Язык.

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Название: Russian
Код: ru
Кодировка: ru_RU.UTF-8,ru_RU,russian
Изображение: ru.png
Директория: russian
Файл перевода: russian
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

Вопросы и предложения : opencart.lite@gmail.com

==============================================================================
English:
-------------------------------------------------------------------------------
Version Opencart v1.5.5.1, v1.5.5.x

Upload folders(admin, catalog) to your OpenCart(root directory) from the "FILES_TO_UPLOAD" folder.

Goto System->Localisation->Languages and Insert the Russian Language.

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Language Name: Russian
Code: ru
Locale: ru_RU.UTF-8,ru_RU,russian
Image: ru.png
Directory: russian
File Name: russian
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

Questions: opencart.lite@gmail.com

===============================================================================
Created by ion special for:
WebSolution
http://www.opencart-lite.com